package br.facom.apsoo.sisauto.model;

import java.util.Calendar;

public class Cliente {
	
	private long id;
	private String nome;
	private String cadastro;
	private String endereco;
	private String cidade;
	private String estado;
	private Calendar dataCadastro;
	

	//getters snd setter
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCadastro() {
		return cadastro;
	}
	public void setCadastro(String cadastro) {
		this.cadastro = cadastro;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Calendar getDataCadastro() {
		return dataCadastro;
	}
	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	public long getId() {
		return id;
	}
	
	public void setId(long id){
		this.id = id;
	}

}
