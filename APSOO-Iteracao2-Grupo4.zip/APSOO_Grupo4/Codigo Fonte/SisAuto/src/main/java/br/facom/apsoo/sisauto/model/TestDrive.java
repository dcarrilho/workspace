package br.facom.apsoo.sisauto.model;

public class TestDrive {
	
	private String veiculo;
	private String cliente;
	private String hsaida;
	private String hchegada;
	private String kmsaida;
	private String kmchegada;
	
	public String getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(String veiculo) {
		this.veiculo = veiculo;
	}
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public String getHsaida() {
		return hsaida;
	}
	public void setHsaida(String hsaida) {
		this.hsaida = hsaida;
	}
	public String getHchegada() {
		return hchegada;
	}
	public void setHchegada(String hchegada) {
		this.hchegada = hchegada;
	}
	public String getKmsaida() {
		return kmsaida;
	}
	public void setKmsaida(String kmsaida) {
		this.kmsaida = kmsaida;
	}
	public String getKmchegada() {
		return kmchegada;
	}
	public void setKmchegada(String kmchegada) {
		this.kmchegada = kmchegada;
	}
	
	

}
